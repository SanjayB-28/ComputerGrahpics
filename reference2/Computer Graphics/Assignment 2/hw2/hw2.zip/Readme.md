# Lorenz Attractor Visualization

This program provides an interactive 3D visualization of the Lorenz Attractor using OpenGL.

## Running the Program

1. Unzip the uploaded file to a directory of your choice.

2. Open a terminal/command prompt and navigate to the directory containing the unzipped files.

3. Run the program:
   - On Windows: 
     ```
     hw2.exe
     ```
   - On macOS/Linux: 
     ```
     ./hw2
     ```

If you need to recompile the program:

1. Ensure you have the necessary development tools installed (gcc, make, OpenGL, and GLUT libraries).

2. In the terminal, run:
   ```
   make
   ```

   or

   #### On macOS:
      ```
      gcc -O3 -Wall -Wno-deprecated-declarations -DRES=1 -o hw2 hw2.c -framework GLUT -framework OpenGL
      ```
    
      #### On Linux/Ubuntu:
      ```
      gcc -O3 -Wall -o hw2 hw2.c -lglut -lGLU -lGL -lm
      ```

      #### On Windows (using MinGW):
      ```
      gcc -O3 -Wall -DUSEGLEW -o hw2.exe hw2.c -lfreeglut -lglew32 -lglu32 -lopengl32
      ```

3. Then run the program as described above.

## Controls

- Arrow keys: Rotate the view
- '+' or '=': Zoom in
- '-' or '_': Zoom out
- 'c' or 'C': Toggle color scheme
- 's': Increase Sigma
- 'S': Decrease Sigma
- 'b': Increase Beta
- 'B': Decrease Beta
- 'r': Increase Rho
- 'R': Decrease Rho
- 'q', 'Q', or ESC: Quit the program

The program starts with an interesting view of the Lorenz attractor. Use the controls to explore the visualization and adjust parameters. All actions are printed in the console for feedback.


## Time to Complete the Assignment:
### Total Time: 6 hours
- Research and Setup: 1 hour
- Coding and Implementation: 3 hours
- Testing and Debugging: 1 hour
- Writing README: 1 hour