#ifndef SOUND_H
#define SOUND_H

int soundSystemInit();
void soundSystemPlayAmbience();
void soundSystemStopAmbience();
void soundSystemCleanup();

#endif 